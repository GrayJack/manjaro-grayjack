 Google Material Design Icons are licensed under Apache License 2.0 (see LICENSE.txt)

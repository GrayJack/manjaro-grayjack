 What to do in every release?

 - Update translations.
 - Update travis version
 - Releases always use annotated tags as in `git tag -a v0.5.1 -m "version 0.5.1"`
 - Add a changelog description in the Github's release.

#ifndef WAYLANDUTILS_H
#define WAYLANDUTILS_H


class WaylandUtils
{
public:
    WaylandUtils();

    static bool waylandDetected();

private:

};

#endif // WAYLANDUTILS_H

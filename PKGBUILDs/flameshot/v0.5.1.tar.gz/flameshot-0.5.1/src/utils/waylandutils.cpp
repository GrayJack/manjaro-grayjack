#include "waylandutils.h"

WaylandUtils::WaylandUtils()
{

}

bool WaylandUtils::waylandDetected() {

}
